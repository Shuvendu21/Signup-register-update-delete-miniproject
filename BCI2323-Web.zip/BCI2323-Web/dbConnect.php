<?php 
$host="localhost";
$dbname='project-bci2323-DB01';
$username='root';
$password='';

$pdo=new PDO("mysql:host=$host;dbname=$dbname",$username,$password);
